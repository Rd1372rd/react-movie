import React from "react";

const AddFavourites = () => {
  return (
    <div>
      <span className="mr-2">Add to Favourites</span>
      <i className="material-icons" style={{ fontSize: "48px", color: "red" }}>
        favorite
      </i>
    </div>
  );
};

export default AddFavourites;
