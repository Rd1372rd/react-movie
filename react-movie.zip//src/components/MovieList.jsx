import React from "react";
import PropTypes from "prop-types";

// تعریف کامپوننت MovieList
const MovieList = (props) => {
  const FavouriteComponent = props.favouriteComponent; // تغییر نام برای سازگاری با نام prop
  return (
    <>
      {props.movies.map((movie) => (
        <div
          className="image-container d-flex justify-content-start m-3"
          key={movie.imdbID} // اضافه کردن key برای جلوگیری از خطای React
        >
          <img src={movie.Poster} alt="movie" />
          <div
            onClick={() => props.handleFavouritesClick(movie)} // اصلاح نام تابع
            className="overlay d-flex align-items-center justify-content-center" // اصلاح نام کلاس
          >
            <FavouriteComponent />
          </div>
        </div>
      ))}
    </>
  );
};

// تعریف نوع props به وسیله PropTypes
MovieList.propTypes = {
  movies: PropTypes.array.isRequired, // movies باید یک آرایه باشد
  handleFavouritesClick: PropTypes.func.isRequired, // تابع برای کلیک
  favouriteComponent: PropTypes.elementType.isRequired, // کامپوننت پاس‌داده‌شده
};

export default MovieList;
